<!DOCTYPE html>
<html lang="es">
	<head>
		
		  	<title>H. Clinica | 404</title>
		  	
	</head>
	<body>

	<!-- <p>Directory no access.</p> -->
	<script type="text/javascript">
		location.href="http://historiasweb.pe.hu/shistoria";
	</script>
	</body>
</html>
